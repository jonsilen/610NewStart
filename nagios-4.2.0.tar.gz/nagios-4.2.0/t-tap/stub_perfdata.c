int update_host_performance_data(host *hst) {}
int update_service_performance_data(service *svc) { return OK; }
